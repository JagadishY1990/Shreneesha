package com.employeeskills.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserDto {
	private String role;
    private String uname;
    private String email;
    private String psw;
    private String status;
}
