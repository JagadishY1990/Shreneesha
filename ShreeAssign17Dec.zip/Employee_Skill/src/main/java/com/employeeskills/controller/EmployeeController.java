package com.employeeskills.controller;


import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import com.employeeskills.Model.EmailDetails;
import com.employeeskills.Service.EmailService;
import com.employeeskills.dto.SearchRequestDto;
import com.employeeskills.utility.EmployeeDataExcelExport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.employeeskills.Model.Employee;
import com.employeeskills.Service.EmployeeService;
import com.employeeskills.constants.ApplicationConstants;
import com.employeeskills.dto.EmployeeDto;
import com.employeeskills.dto.UserDto;
import com.employeeskills.dto.UserDto;
//import com.employeeskills.utility.EmployeeDataExcelExport;
import com.employeeskills.utility.EmployeeDataExcelExport;
import com.employeeskills.utility.EmployeeDataPdfExport;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @Autowired
    private EmailService emailService;

    private String searchByTemp = "";
    private String searchValueTemp ="";
    
    // inserting employee
    @GetMapping("/login")
    public String login() {
        log.info("Received request for login");
        return ApplicationConstants.LOGIN_SCREEN;
    }
    
    // inserting employee
    @PostMapping("/loginSubmit")
    public String loginSubmit(HttpServletRequest request, @ModelAttribute UserDto loginDto) {
        log.info("Received request for login");
        String status = employeeService.login(loginDto);
        loginDto.setStatus(status);
        loginDto.setRole("ADMIN");
        request.getSession().setAttribute("userObject", loginDto);
        request.setAttribute("loginDetails", loginDto);
        checkIsAdmin(loginDto, request);
        if(status.equalsIgnoreCase("SUCCESS")) {
        	return showHomePage(request);
        }else {
        	return ApplicationConstants.LOGIN_SCREEN;
        }
    }

    private void checkIsAdmin(UserDto loginDto, HttpServletRequest request) {
		if(null!= loginDto) {
			if(loginDto.getRole().equalsIgnoreCase("ADMIN"))
				request.setAttribute("isAdmin", "true");
			    request.setAttribute("loggedinUser", loginDto.getUname());
		}
	}

	// displaying list of all employees
    @GetMapping("/employees")
    public String getAllEmployee(HttpServletRequest request) {
        log.info("Received request for getting all employees");
        List<Employee> empList = new ArrayList<>();
        UserDto loginDto = (UserDto) request.getSession().getAttribute("userObject");
        empList = employeeService.getAllEmployees();
        log.info("Total num of employees = " + empList.size());
        request.setAttribute("listEmployee", empList);
        checkIsAdmin(loginDto, request);
        return ApplicationConstants.EMP_LIST_SCREEN;
    }

    @GetMapping("/home")
    public String showHomePage(HttpServletRequest request) {
        log.info("Received request for home page");
        UserDto loginDto = (UserDto) request.getSession().getAttribute("userObject");
        
        checkIsAdmin(loginDto, request);
        return ApplicationConstants.EMP_LIST_SCREEN;
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(HttpServletRequest request, @PathVariable int id) {
        log.info("Received request for getting all employees");
        Optional<Employee> existingEmployee = employeeService.getEmployee(id);
        if (existingEmployee.isPresent())
            request.setAttribute("employee", existingEmployee.get());
        UserDto loginDto = (UserDto) request.getSession().getAttribute("userObject");
         checkIsAdmin(loginDto, request);
        return ApplicationConstants.EMP_FORM_SCREEN;
    }

    // displaying employee by id
    @GetMapping("/employees/{id}")
    public String getEmployee(HttpServletRequest request, @PathVariable int id) {
        log.info("Received request for getting employee with empid =" + id);
        Optional<Employee> existingEmployee = employeeService.getEmployee(id);
        if (existingEmployee.isPresent())
            request.setAttribute("employee", existingEmployee.get());
        UserDto loginDto = (UserDto) request.getSession().getAttribute("userObject");
        checkIsAdmin(loginDto, request);
        return ApplicationConstants.EMP_FORM_SCREEN;
    }
    
    @GetMapping("/editEmployees/{name}")
    public String getEmployee(HttpServletRequest request, @PathVariable String name) {
        log.info("Received request for getting employee with name =" + name);
        Optional<Employee> existingEmployee = employeeService.getEmployeeByName(name);
        if (existingEmployee.isPresent())
            request.setAttribute("employee", existingEmployee.get());
        UserDto loginDto = (UserDto) request.getSession().getAttribute("userObject");
        checkIsAdmin(loginDto, request);
        return ApplicationConstants.EMP_FORM_SCREEN;
    }
    
    // inserting employee
    @PostMapping("/addEmployees")
    public String addEmployees(HttpServletRequest request, @ModelAttribute EmployeeDto empDto) {
        log.info("Received request for adding employee with emp Name =" + empDto.getEmpname());
        employeeService.addEmployee(empDto);
        UserDto loginDto = (UserDto) request.getSession().getAttribute("userObject");
        checkIsAdmin(loginDto, request);
        return getAllEmployee(request);
    }

    //updating employee by id
    @PostMapping("/updateEmployee/{id}")
    public String updateEmployee(@ModelAttribute EmployeeDto empDto, @PathVariable int id, HttpServletRequest request) {
        log.info("Received request for updating employee with empid =" + id);
        employeeService.updateEmployee(empDto, id);
        log.info("Successfully updated employee with empid = " + id);
        UserDto loginDto = (UserDto) request.getSession().getAttribute("userObject");
        checkIsAdmin(loginDto, request);
        request.setAttribute("message","Successfully updated employee with id = "+id);
        return getAllEmployee(request);
    }

    // deleting employee by id
    @GetMapping("/deleteEmployee/{id}")
    public String deleteEmployeeByID(@PathVariable int id, HttpServletRequest request) {
        log.info("Received request for deleting employee with empid =" + id);
        employeeService.deleteEmployeeByID(id);
        log.info("Successfully deleted employee with empid =" + id);
        UserDto loginDto = (UserDto) request.getSession().getAttribute("userObject");
         checkIsAdmin(loginDto, request);
         request.setAttribute("message","Successfully deleted employee with id = "+id);
        return getAllEmployee(request);
    }
    
 // deleting employee by id
    @GetMapping("/forgotPassword")
    public String deleteEmployeeByID(HttpServletRequest request) {
        log.info("Received request for Forgot Password");
        return ApplicationConstants.FORGOT_PASSWORD_SCREEN;
    }
    
    // inserting employee
    @PostMapping("/saveUsers")
    public String addUsersForLogin(HttpServletRequest request, @ModelAttribute UserDto userDto) {
        employeeService.addUsers(userDto);
        request.setAttribute("isUserAdded", "true");
        return ApplicationConstants.ADD_USERS_SCREEN;
    }
    
    // inserting employee
    @GetMapping("/addUsers")
    public String addUsers() {
    	return ApplicationConstants.ADD_USERS_SCREEN;
    }
    
    @GetMapping("/employee/pdf/{searchBy}/{searchValue}")
    public ModelAndView exportToPdf(HttpServletRequest request,@PathVariable String searchBy, @PathVariable String searchValue) {
        ModelAndView mav = new ModelAndView();
        mav.setView(new EmployeeDataPdfExport());
        List<Employee> list= new ArrayList<>();//employeeService.getAllEmployees();
        list = employeeService.getAllEmployeesBySearch(searchBy, searchValue);
        mav.addObject("list", list);
        return mav; 
    }
    
    // displaying list of all employees
    @PostMapping("/employee/searchEmployee")
    public String getAllEmployeeBasedOnSearch(HttpServletRequest request, @ModelAttribute SearchRequestDto requestDto) {
        log.info("Received request for getting all employees by search");
        List<Employee> empList = new ArrayList<>();
        UserDto loginDto = (UserDto) request.getSession().getAttribute("userObject");
        empList = employeeService.getAllEmployeesBySearch(requestDto.getSearchBy(), requestDto.getSearchValue());
        searchByTemp = requestDto.getSearchBy();
        searchValueTemp = requestDto.getSearchValue();
        log.info("Total num of employees = " + empList.size());
        request.setAttribute("listEmployee", empList);
        checkIsAdmin(loginDto, request);
        return ApplicationConstants.EMP_LIST_SCREEN;
    }

    @GetMapping("/employee/excel")
    public ModelAndView exportToExcel(HttpServletRequest request) {
        ModelAndView mav = new ModelAndView();
        mav.setView(new EmployeeDataExcelExport());
        List<Employee> list= new ArrayList<>();//employeeService.getAllEmployees();
        list = employeeService.getAllEmployeesBySearch(searchByTemp, searchValueTemp);
        mav.addObject("list", list);
        return mav;
    }

    @GetMapping("/employee/sendEmail")
    public String sendEmail(HttpServletRequest request) {
        ModelAndView mav = new ModelAndView();
        log.info("Received request for Send email");
        String emailId = "bharathkumar686@gmail.com";
        String status = emailService.sendSimpleMail(emailId);
        log.info("Email sent successfully");
        log.info(status);
        return status;
    }

}

