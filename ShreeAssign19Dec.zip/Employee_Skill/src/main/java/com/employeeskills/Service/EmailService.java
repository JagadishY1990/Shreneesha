package com.employeeskills.Service;

import com.employeeskills.constants.ApplicationConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.employeeskills.constants.ApplicationConstants;

@Service
public class EmailService {

    @Autowired
    private JavaMailSender javaMailSender;

    @Value("${spring.mail.username}")
    private String sender;

    public String sendSimpleMail(String emailId)
    {

        try {
            SimpleMailMessage mailMessage = new SimpleMailMessage();

            // Setting up necessary details
            mailMessage.setFrom(sender);
            mailMessage.setTo(emailId);
            mailMessage.setText(ApplicationConstants.EMAIL_BODY + ApplicationConstants.PASSWORD);
            mailMessage.setSubject(ApplicationConstants.EMAIL_SUBJECT);

            // Sending the mail
            javaMailSender.send(mailMessage);
            return "Mail Sent Successfully...";
        }

        // Catch block to handle the exceptions
        catch (Exception e) {
            return "Error while Sending Mail = " + e.getMessage();
        }
    }
}