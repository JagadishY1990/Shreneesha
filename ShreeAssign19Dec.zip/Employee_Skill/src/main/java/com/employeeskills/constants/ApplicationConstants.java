package com.employeeskills.constants;

public class ApplicationConstants {
    public static final String EMP_LIST_SCREEN = "employeeList";
    public static final String EMP_FORM_SCREEN = "employee-form";
    public static final String LOGIN_SCREEN = "login-form";
    public static final String FORGOT_PASSWORD_SCREEN = "forgot-password";
    public static final String ADD_USERS_SCREEN = "add-users";
    public static final String RESET_PASSWORD_SCREEN = "reset-password";
     public static final String EMAIL_SUBJECT = "Password Reset Successful";

    public static final String EMAIL_BODY = "You password has been reset to : ";
    public static final String PASSWORD = "Temp-123";
}
