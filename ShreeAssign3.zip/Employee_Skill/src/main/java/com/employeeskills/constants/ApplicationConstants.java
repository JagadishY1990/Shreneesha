package com.employeeskills.constants;

public class ApplicationConstants {
    public static final String EMP_LIST_SCREEN = "employeeList";
    public static final String EMP_FORM_SCREEN = "employee-form";
    public static final String LOGIN_SCREEN = "login-form";
}
