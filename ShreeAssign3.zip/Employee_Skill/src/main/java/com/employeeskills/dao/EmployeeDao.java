package com.employeeskills.dao;


import com.employeeskills.Model.Employee;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

// interface extending crud repository
public interface EmployeeDao extends CrudRepository<Employee, Integer> {

	Optional<Employee> findByEmpname(String uname);

	List<Employee> findAllByEmpname(String searchValue);

	List<Employee> findAllByYearsofexperience(int searchValue);

	List<Employee> findAllByCertification(String searchValue);

	List<Employee> findAllByQualification(String searchValue);

	List<Employee> findAllByDepartment(String searchValue);

	List<Employee> findAllByTechnicalskills(String searchValue);

	List<Employee> findAllByEmployeeID(int parseInt);

}
